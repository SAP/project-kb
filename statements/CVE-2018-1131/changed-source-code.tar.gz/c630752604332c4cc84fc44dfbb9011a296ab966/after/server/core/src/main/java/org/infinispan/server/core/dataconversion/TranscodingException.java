package org.infinispan.server.core.dataconversion;

public class TranscodingException extends RuntimeException {

   public TranscodingException(String message) {
      super(message);
   }
}
