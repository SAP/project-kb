/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.druid.security.authentication.validator;

import org.apache.druid.security.basic.authentication.validator.LDAPCredentialsValidator;
import org.junit.Assert;
import org.junit.Test;

public class LDAPCredentialsValidatorTest
{
  @Test
  public void testEncodeForLDAP_noSpecialChars()
  {
    String input = "user1";
    String encoded = LDAPCredentialsValidator.encodeForLDAP(input, true);
    Assert.assertEquals(input, encoded);
  }

  @Test
  public void testEncodeForLDAP_specialChars()
  {
    String input = "user1\\*()\0/user1";
    String encodedWildcardTrue = LDAPCredentialsValidator.encodeForLDAP(input, true);
    String encodedWildcardFalse = LDAPCredentialsValidator.encodeForLDAP(input, false);
    String expectedWildcardTrue = "user1\\5c\\2a\\28\\29\\00\\2fuser1";
    String expectedWildcardFalse = "user1\\5c*\\28\\29\\00\\2fuser1";
    Assert.assertEquals(expectedWildcardTrue, encodedWildcardTrue);
    Assert.assertEquals(expectedWildcardFalse, encodedWildcardFalse);
  }
}
