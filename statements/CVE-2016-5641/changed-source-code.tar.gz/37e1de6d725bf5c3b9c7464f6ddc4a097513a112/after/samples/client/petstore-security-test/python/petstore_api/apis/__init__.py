from __future__ import absolute_import

# import apis into api package
from .fake_api import FakeApi
