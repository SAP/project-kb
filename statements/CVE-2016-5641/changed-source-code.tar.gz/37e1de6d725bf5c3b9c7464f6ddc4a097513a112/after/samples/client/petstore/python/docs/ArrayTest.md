# ArrayTest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**array_of_string** | **list[str]** |  | [optional] 
**array_array_of_integer** | **list[list[int]]** |  | [optional] 
**array_array_of_model** | **list[list[ReadOnlyFirst]]** |  | [optional] 
**array_of_enum** | **list[str]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


