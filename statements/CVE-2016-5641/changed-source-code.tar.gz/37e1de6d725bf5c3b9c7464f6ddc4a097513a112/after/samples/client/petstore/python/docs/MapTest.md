# MapTest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**map_map_of_string** | [**dict(str, dict(str, str))**](dict.md) |  | [optional] 
**map_map_of_enum** | [**dict(str, dict(str, str))**](dict.md) |  | [optional] 
**map_of_enum_string** | **dict(str, str)** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


