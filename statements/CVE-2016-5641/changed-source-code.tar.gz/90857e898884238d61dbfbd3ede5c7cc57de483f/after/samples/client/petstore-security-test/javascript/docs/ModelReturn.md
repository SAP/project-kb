# SwaggerPetstoreEnd.ModelReturn

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_return** | **Integer** | property description   &#39; \&quot; &#x3D;end | [optional] 


