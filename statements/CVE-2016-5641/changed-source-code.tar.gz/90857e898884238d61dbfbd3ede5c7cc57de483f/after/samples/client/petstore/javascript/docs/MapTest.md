# SwaggerPetstore.MapTest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mapMapOfString** | **{String: {String: String}}** |  | [optional] 
**mapOfEnumString** | **{String: String}** |  | [optional] 


<a name="{String: String}"></a>
## Enum: {String: String}





