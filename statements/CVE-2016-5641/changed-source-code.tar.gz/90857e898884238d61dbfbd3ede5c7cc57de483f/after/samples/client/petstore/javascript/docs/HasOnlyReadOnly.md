# SwaggerPetstore.HasOnlyReadOnly

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bar** | **String** |  | [optional] 
**foo** | **String** |  | [optional] 


