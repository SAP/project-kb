# SwaggerPetstore.ArrayOfArrayOfNumberOnly

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**arrayArrayNumber** | **[[Number]]** |  | [optional] 


