# SwaggerPetstore.NumberOnly

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**justNumber** | **Number** |  | [optional] 


