# SwaggerPetstore.ArrayOfNumberOnly

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**arrayNumber** | **[Number]** |  | [optional] 


