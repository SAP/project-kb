# SwaggerPetstore.Model200Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **Integer** |  | [optional] 


