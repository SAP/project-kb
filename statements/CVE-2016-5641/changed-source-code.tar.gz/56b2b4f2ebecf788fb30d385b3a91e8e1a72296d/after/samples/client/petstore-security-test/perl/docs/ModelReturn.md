# WWW::SwaggerClient::Object::ModelReturn

## Load the model package
```perl
use WWW::SwaggerClient::Object::ModelReturn;
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**return** | **int** | property description  */ &#39; \&quot;  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


