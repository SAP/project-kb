# IO.Swagger.Model.ModelReturn
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_Return** | **int?** | property description   &#39; \&quot; &#x3D;end | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

