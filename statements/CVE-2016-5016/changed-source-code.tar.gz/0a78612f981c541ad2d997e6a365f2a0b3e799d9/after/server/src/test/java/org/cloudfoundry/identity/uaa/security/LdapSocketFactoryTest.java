package org.cloudfoundry.identity.uaa.security;

import static org.junit.Assert.*;

public class LdapSocketFactoryTest {

}
